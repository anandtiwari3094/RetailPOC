package com.synechron.retail;
import com.synechron.retail.Orders;
import com.synechron.retail.Customer;
public class Retail {
	public void calculatePriceAfterDiscount(Customer cust,Orders orders)
	{
		if(cust.getDiscountCategory().equalsIgnoreCase("StoreEmployee"))
			System.out.println("The amount is::"+0.7*orders.getTotal_amount());
		else if(cust.getDiscountCategory().equalsIgnoreCase("StoreAfilliate"))
			System.out.println("The amount is::"+0.9*orders.getTotal_amount());
		else if(cust.getDiscountCategory().equalsIgnoreCase("cust2Plus"))
			System.out.println("The amount is::"+0.95*orders.getTotal_amount());
		
	}
	
public static void main(String args[])
{
	Retail retail=new Retail();
	Customer cust=new Customer();
	cust.setCustId("A1");
	cust.setCustName("Sapna");
	cust.setDiscountCategory("StoreEmployee");
	
	Orders orders=new Orders();
	orders.setOrderID("O1");
	orders.setTotal_amount(1000);
	System.out.println("Calculating the price for customer::"+cust.getCustName() +"with order "+orders.getOrderID());
	
	//Retail retail=new Retail();
	retail.calculatePriceAfterDiscount(cust, orders);
	
}
}
